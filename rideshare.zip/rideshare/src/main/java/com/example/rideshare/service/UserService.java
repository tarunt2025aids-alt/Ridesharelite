package com.example.rideshare.service;

import com.example.rideshare.entity.RideOffer;
import com.example.rideshare.entity.User;
import com.example.rideshare.repository.RideOfferRepository;
import com.example.rideshare.repository.RideRequestRepository;
import com.example.rideshare.repository.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class UserService {

    private final UserRepository userRepository;
    private final RideOfferRepository rideOfferRepository;
    private final RideRequestRepository rideRequestRepository;

    public UserService(UserRepository userRepository,
                       RideOfferRepository rideOfferRepository,
                       RideRequestRepository rideRequestRepository) {
        this.userRepository = userRepository;
        this.rideOfferRepository = rideOfferRepository;
        this.rideRequestRepository = rideRequestRepository;
    }

    public User createUser(User user) {
        return userRepository.save(user);
    }

    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    public User getUserById(Long id) {
        return userRepository.findById(id)
                .orElseThrow(() ->
                        new RuntimeException("User not found with ID: " + id));
    }

    public User updateUser(Long id, User updatedUser) {
        User existing = getUserById(id);
        existing.setName(updatedUser.getName());
        existing.setEmail(updatedUser.getEmail());
        existing.setPhone(updatedUser.getPhone());
        return userRepository.save(existing);
    }

    @Transactional
    public void deleteUser(Long id) {
        User user = getUserById(id);
        // Clean up any ride requests where user is rider
        rideRequestRepository.deleteByRiderId(id);

        // Find all ride offers by this driver and remove associated requests first
        List<RideOffer> rides = rideOfferRepository.findByDriverId(id);
        for (RideOffer ride : rides) {
            rideRequestRepository.deleteByRideOfferId(ride.getId());
        }
        rideOfferRepository.deleteByDriverId(id);

        // Delete user
        userRepository.delete(user);
    }
}