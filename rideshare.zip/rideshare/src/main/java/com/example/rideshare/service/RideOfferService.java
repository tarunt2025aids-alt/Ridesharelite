package com.example.rideshare.service;

import com.example.rideshare.entity.RideOffer;
import com.example.rideshare.entity.User;
import com.example.rideshare.repository.RideOfferRepository;
import com.example.rideshare.repository.RideRequestRepository;
import com.example.rideshare.repository.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class RideOfferService {

    private final RideOfferRepository rideRepository;
    private final RideRequestRepository rideRequestRepository;
    private final UserRepository userRepository;

    public RideOfferService(RideOfferRepository rideRepository,
                            RideRequestRepository rideRequestRepository,
                            UserRepository userRepository) {
        this.rideRepository = rideRepository;
        this.rideRequestRepository = rideRequestRepository;
        this.userRepository = userRepository;
    }

    public RideOffer createRide(RideOffer ride) {
        if (ride.getSeatsAvailable() <= 0) {
            throw new RuntimeException("Seats must be greater than zero");
        }
        if (ride.getDriver() != null && ride.getDriver().getId() != null) {
            User driver = userRepository.findById(ride.getDriver().getId())
                    .orElseThrow(() -> new RuntimeException("Driver not found with ID: " + ride.getDriver().getId()));
            ride.setDriver(driver);
        }
        return rideRepository.save(ride);
    }

    public List<RideOffer> getAllRides() {
        return rideRepository.findAll();
    }

    public RideOffer getRideById(Long id) {
        return rideRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Ride not found with ID: " + id));
    }

    public List<RideOffer> searchRide(String origin, String destination) {
        return rideRepository.findByOriginAndDestination(origin, destination);
    }

    public RideOffer updateRide(Long id, RideOffer updatedRide) {
        RideOffer existing = getRideById(id);

        if (updatedRide.getSeatsAvailable() <= 0) {
            throw new RuntimeException("Seats must be greater than zero");
        }

        if (updatedRide.getOrigin() != null && !updatedRide.getOrigin().trim().isEmpty()) {
            existing.setOrigin(updatedRide.getOrigin().trim());
        }
        if (updatedRide.getDestination() != null && !updatedRide.getDestination().trim().isEmpty()) {
            existing.setDestination(updatedRide.getDestination().trim());
        }
        if (updatedRide.getDepartureTime() != null) {
            existing.setDepartureTime(updatedRide.getDepartureTime());
        }
        existing.setSeatsAvailable(updatedRide.getSeatsAvailable());

        if (updatedRide.getDriver() != null && updatedRide.getDriver().getId() != null) {
            User driver = userRepository.findById(updatedRide.getDriver().getId())
                    .orElseThrow(() -> new RuntimeException("Driver not found with ID: " + updatedRide.getDriver().getId()));
            existing.setDriver(driver);
        }

        return rideRepository.save(existing);
    }

    @Transactional
    public void deleteRide(Long id) {
        RideOffer existing = getRideById(id);
        rideRequestRepository.deleteByRideOfferId(id);
        rideRepository.delete(existing);
    }
}