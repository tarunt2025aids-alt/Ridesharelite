package com.example.rideshare.repository;

import com.example.rideshare.entity.RideRequest;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface RideRequestRepository
        extends JpaRepository<RideRequest, Long> {

    List<RideRequest> findByRideOfferId(Long rideOfferId);

    void deleteByRideOfferId(Long rideOfferId);

    List<RideRequest> findByRiderId(Long riderId);

    void deleteByRiderId(Long riderId);
}
