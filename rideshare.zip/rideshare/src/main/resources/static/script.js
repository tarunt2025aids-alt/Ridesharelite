// RideShareLite JavaScript Application
const API_BASE = window.location.origin;

// State management
let state = {
  users: [],
  rides: [],
  pendingDeleteAction: null
};

// --- INITIALIZATION ---
document.addEventListener("DOMContentLoaded", () => {
  loadUsers();
  loadAllRides();
  setupModalBackdrops();
});

// Toast notification helper
function showToast(message, type = "success") {
  const container = document.getElementById("toastContainer");
  if (!container) return;

  const toast = document.createElement("div");
  toast.className = `toast ${type}`;
  
  let icon = "✅";
  if (type === "error") icon = "❌";
  if (type === "info") icon = "ℹ️";

  toast.innerHTML = `<span>${icon}</span><span>${escapeHtml(message)}</span>`;
  container.appendChild(toast);

  setTimeout(() => {
    toast.style.animation = "fadeOut 0.3s ease forwards";
    setTimeout(() => toast.remove(), 300);
  }, 3500);
}

// Utility: escape HTML to prevent XSS
function escapeHtml(str) {
  if (str === null || str === undefined) return "";
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

// Format ISO date string nicely
function formatDate(dateStr) {
  if (!dateStr) return "N/A";
  try {
    const d = new Date(dateStr);
    if (isNaN(d.getTime())) return dateStr;
    return d.toLocaleString("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit"
    });
  } catch (e) {
    return dateStr;
  }
}

// Format date for datetime-local input
function formatForInput(dateStr) {
  if (!dateStr) return "";
  try {
    const d = new Date(dateStr);
    if (isNaN(d.getTime())) return "";
    const pad = num => String(num).padStart(2, "0");
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
  } catch (e) {
    return "";
  }
}

// Update stats strip counters
function updateStats() {
  const totalUsersEl = document.getElementById("statTotalUsers");
  const totalRidesEl = document.getElementById("statTotalRides");
  const totalSeatsEl = document.getElementById("statTotalSeats");

  if (totalUsersEl) totalUsersEl.textContent = state.users.length;
  if (totalRidesEl) totalRidesEl.textContent = state.rides.length;
  if (totalSeatsEl) {
    const seats = state.rides.reduce((sum, r) => sum + (Number(r.seatsAvailable) || 0), 0);
    totalSeatsEl.textContent = seats;
  }

  // Update badge counters
  const userCountBadge = document.getElementById("userCountBadge");
  if (userCountBadge) userCountBadge.textContent = `${state.users.length} Users`;

  const ridesCountBadge = document.getElementById("ridesCountBadge");
  if (ridesCountBadge) ridesCountBadge.textContent = `${state.rides.length} Available`;
}

// --- USER MANAGEMENT ---

async function loadUsers() {
  try {
    const res = await fetch(`${API_BASE}/users`);
    if (!res.ok) throw new Error("Could not retrieve users list");
    const data = await res.json();
    state.users = Array.isArray(data) ? data : [];
    renderUsers();
    populateDriverSelect();
    updateStats();
  } catch (error) {
    console.error("Error loading users:", error);
    const userGrid = document.getElementById("userList");
    if (userGrid) {
      userGrid.innerHTML = `
        <div class="empty-state">
          <div class="empty-icon">⚠️</div>
          <p>Failed to load users: ${escapeHtml(error.message)}</p>
        </div>`;
    }
  }
}

function renderUsers() {
  const userGrid = document.getElementById("userList");
  if (!userGrid) return;

  if (state.users.length === 0) {
    userGrid.innerHTML = `
      <div class="empty-state" style="grid-column: 1 / -1;">
        <div class="empty-icon">👥</div>
        <p>No registered users yet. Create your first user above!</p>
      </div>`;
    return;
  }

  userGrid.innerHTML = state.users.map(u => {
    const initial = (u.name || "U").trim().charAt(0).toUpperCase();
    return `
      <div class="user-card" id="user-card-${u.id}">
        <div class="user-card-header">
          <div class="avatar">${escapeHtml(initial)}</div>
          <div class="user-info">
            <h4>${escapeHtml(u.name)}</h4>
            <span class="user-id-badge">User ID: #${u.id}</span>
          </div>
        </div>
        <div class="user-details">
          <div>📧 <span>${escapeHtml(u.email || "No email")}</span></div>
          <div>📞 <span>${escapeHtml(u.phone || "No phone")}</span></div>
        </div>
        <div class="card-actions">
          <button class="btn-sm btn-edit" onclick="openEditUserModal(${u.id})">
            ✏️ Edit
          </button>
          <button class="btn-sm btn-delete" onclick="confirmDeleteUser(${u.id}, '${escapeHtml(u.name)}')">
            🗑️ Delete
          </button>
        </div>
      </div>
    `;
  }).join("");
}

function populateDriverSelect() {
  const driverSelect = document.getElementById("driverSelect");
  const editDriverSelect = document.getElementById("editDriverSelect");

  const buildOptions = () => {
    if (state.users.length === 0) {
      return `<option value="">-- No users registered yet --</option>`;
    }
    return [
      `<option value="">-- Select Registered Driver --</option>`,
      ...state.users.map(u => `<option value="${u.id}">#${u.id} - ${escapeHtml(u.name)} (${escapeHtml(u.email)})</option>`)
    ].join("");
  };

  if (driverSelect) {
    const currentVal = driverSelect.value;
    driverSelect.innerHTML = buildOptions();
    if (currentVal) driverSelect.value = currentVal;
  }
  if (editDriverSelect) {
    editDriverSelect.innerHTML = buildOptions();
  }
}

async function createUser() {
  const nameInput = document.getElementById("name");
  const emailInput = document.getElementById("email");
  const phoneInput = document.getElementById("phone");

  const name = nameInput.value.trim();
  const email = emailInput.value.trim();
  const phone = phoneInput.value.trim();

  if (!name || !email || !phone) {
    showToast("Please fill in name, email, and phone number.", "error");
    return;
  }

  try {
    const response = await fetch(`${API_BASE}/users`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, email, phone })
    });

    if (!response.ok) {
      const errText = await response.text();
      throw new Error(errText || "User creation failed");
    }

    const newUser = await response.json();
    showToast(`User '${newUser.name}' created with ID #${newUser.id}!`, "success");

    nameInput.value = "";
    emailInput.value = "";
    phoneInput.value = "";

    await loadUsers();
  } catch (error) {
    console.error("Error creating user:", error);
    showToast(`Failed to create user: ${error.message}`, "error");
  }
}

// --- EDIT USER ---

function openEditUserModal(userId) {
  const user = state.users.find(u => u.id === userId);
  if (!user) {
    showToast("User not found", "error");
    return;
  }

  document.getElementById("editUserId").value = user.id;
  document.getElementById("editUserName").value = user.name || "";
  document.getElementById("editUserEmail").value = user.email || "";
  document.getElementById("editUserPhone").value = user.phone || "";

  openModal("editUserModal");
}

async function saveUserEdit() {
  const id = document.getElementById("editUserId").value;
  const name = document.getElementById("editUserName").value.trim();
  const email = document.getElementById("editUserEmail").value.trim();
  const phone = document.getElementById("editUserPhone").value.trim();

  if (!name || !email || !phone) {
    showToast("Please provide all required fields", "error");
    return;
  }

  try {
    const res = await fetch(`${API_BASE}/users/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, email, phone })
    });

    if (!res.ok) {
      const err = await res.text();
      throw new Error(err || "Failed to update user");
    }

    const updated = await res.json();
    showToast(`User #${updated.id} (${updated.name}) updated successfully!`, "success");
    closeModal("editUserModal");
    await loadUsers();
    await loadAllRides();
  } catch (error) {
    console.error("Error updating user:", error);
    showToast(`Failed to update user: ${error.message}`, "error");
  }
}

// --- DELETE USER ---

function confirmDeleteUser(id, userName) {
  state.pendingDeleteAction = async () => {
    try {
      const res = await fetch(`${API_BASE}/users/${id}`, { method: "DELETE" });
      if (!res.ok) {
        const err = await res.text();
        throw new Error(err || "Failed to delete user");
      }
      showToast(`User #${id} (${userName}) deleted successfully`, "success");
      closeModal("confirmDeleteModal");
      await loadUsers();
      await loadAllRides();
    } catch (error) {
      console.error("Error deleting user:", error);
      showToast(`Delete failed: ${error.message}`, "error");
    }
  };

  document.getElementById("confirmDeleteTitle").textContent = "Delete User";
  document.getElementById("confirmDeleteMessage").innerHTML = `
    Are you sure you want to delete user <strong>${escapeHtml(userName)} (ID: #${id})</strong>?<br><br>
    <span style="color: var(--danger); font-size: 13px;">⚠️ Note: Any published rides or requests associated with this user will also be removed.</span>
  `;

  openModal("confirmDeleteModal");
}

// --- RIDE MANAGEMENT ---

async function loadAllRides() {
  try {
    const res = await fetch(`${API_BASE}/rides`);
    if (!res.ok) throw new Error("Could not retrieve rides list");
    const data = await res.json();
    state.rides = Array.isArray(data) ? data : [];
    renderRides(state.rides, "allRidesList");
    updateStats();
  } catch (error) {
    console.error("Error loading rides:", error);
    const container = document.getElementById("allRidesList");
    if (container) {
      container.innerHTML = `
        <div class="empty-state">
          <div class="empty-icon">⚠️</div>
          <p>Failed to load rides: ${escapeHtml(error.message)}</p>
        </div>`;
    }
  }
}

function renderRides(rides, containerId) {
  const container = document.getElementById(containerId);
  if (!container) return;

  if (!rides || rides.length === 0) {
    container.innerHTML = `
      <div class="empty-state" style="grid-column: 1 / -1;">
        <div class="empty-icon">🚗</div>
        <p>No rides available right now.</p>
      </div>`;
    return;
  }

  container.innerHTML = rides.map(ride => {
    const driverName = (ride.driver && ride.driver.name) ? ride.driver.name : `Driver #${ride.driver ? ride.driver.id : 'N/A'}`;
    const seats = Number(ride.seatsAvailable) || 0;
    const seatClass = seats <= 1 ? "seat-pill few" : "seat-pill";

    return `
      <div class="ride-card" id="ride-card-${ride.id}">
        <div class="ride-header">
          <span class="ride-id-tag">Ride #${ride.id}</span>
          <span class="${seatClass}">💺 ${seats} Seat${seats === 1 ? '' : 's'}</span>
        </div>

        <div class="ride-route">
          <div class="route-stop">
            <span class="route-icon-origin">●</span>
            <span>${escapeHtml(ride.origin)}</span>
          </div>
          <div class="route-line"></div>
          <div class="route-stop">
            <span class="route-icon-dest">●</span>
            <span>${escapeHtml(ride.destination)}</span>
          </div>
        </div>

        <div class="ride-meta">
          <div>🕒 <span><strong>Departure:</strong> ${escapeHtml(formatDate(ride.departureTime))}</span></div>
          <div>👤 <span><strong>Driver:</strong> ${escapeHtml(driverName)} (ID: #${ride.driver ? ride.driver.id : '?'})</span></div>
        </div>

        <div class="card-actions">
          <button class="btn-sm btn-edit" onclick="openEditRideModal(${ride.id})">
            ✏️ Edit
          </button>
          <button class="btn-sm btn-delete" onclick="confirmDeleteRide(${ride.id}, '${escapeHtml(ride.origin)}', '${escapeHtml(ride.destination)}')">
            🗑️ Delete
          </button>
        </div>
      </div>
    `;
  }).join("");
}

async function publishRide() {
  const driverSelect = document.getElementById("driverSelect");
  const customDriverId = document.getElementById("driverId");
  const originInput = document.getElementById("origin");
  const destinationInput = document.getElementById("destination");
  const departureInput = document.getElementById("departureTime");
  const seatsInput = document.getElementById("seats");

  // Determine driver ID: dropdown takes precedence if selected, else custom ID input
  let driverId = driverSelect ? driverSelect.value.trim() : "";
  if (!driverId && customDriverId) {
    driverId = customDriverId.value.trim();
  }

  const origin = originInput.value.trim();
  const destination = destinationInput.value.trim();
  const departureTime = departureInput.value.trim();
  const seats = seatsInput.value.trim();

  if (!driverId) {
    showToast("Please select a registered driver or enter a driver ID.", "error");
    return;
  }

  if (!origin || !destination || !departureTime || !seats) {
    showToast("Please fill in all ride details.", "error");
    return;
  }

  if (Number(seats) <= 0) {
    showToast("Available seats must be 1 or more.", "error");
    return;
  }

  const ridePayload = {
    origin,
    destination,
    departureTime,
    seatsAvailable: Number(seats),
    driver: { id: Number(driverId) }
  };

  try {
    const response = await fetch(`${API_BASE}/rides`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(ridePayload)
    });

    if (!response.ok) {
      const errText = await response.text();
      throw new Error(errText || "Failed to publish ride");
    }

    const data = await response.json();
    showToast(`Ride #${data.id} published successfully (${origin} ➔ ${destination})!`, "success");

    // Reset inputs
    originInput.value = "";
    destinationInput.value = "";
    departureInput.value = "";
    seatsInput.value = "";
    if (customDriverId) customDriverId.value = "";

    await loadAllRides();
  } catch (error) {
    console.error("Error publishing ride:", error);
    showToast(`Publishing failed: ${error.message}`, "error");
  }
}

// --- EDIT RIDE ---

function openEditRideModal(rideId) {
  const ride = state.rides.find(r => r.id === rideId);
  if (!ride) {
    showToast("Ride not found", "error");
    return;
  }

  document.getElementById("editRideId").value = ride.id;
  document.getElementById("editRideOrigin").value = ride.origin || "";
  document.getElementById("editRideDestination").value = ride.destination || "";
  document.getElementById("editRideDeparture").value = formatForInput(ride.departureTime);
  document.getElementById("editRideSeats").value = ride.seatsAvailable || 1;

  const editDriverSelect = document.getElementById("editDriverSelect");
  if (editDriverSelect && ride.driver && ride.driver.id) {
    editDriverSelect.value = ride.driver.id;
  }

  openModal("editRideModal");
}

async function saveRideEdit() {
  const id = document.getElementById("editRideId").value;
  const origin = document.getElementById("editRideOrigin").value.trim();
  const destination = document.getElementById("editRideDestination").value.trim();
  const departureTime = document.getElementById("editRideDeparture").value.trim();
  const seats = document.getElementById("editRideSeats").value.trim();
  const driverSelect = document.getElementById("editDriverSelect");
  const driverId = driverSelect ? driverSelect.value : "";

  if (!origin || !destination || !departureTime || !seats) {
    showToast("Please fill in all ride fields", "error");
    return;
  }

  if (Number(seats) <= 0) {
    showToast("Seats must be at least 1", "error");
    return;
  }

  const payload = {
    origin,
    destination,
    departureTime,
    seatsAvailable: Number(seats)
  };

  if (driverId) {
    payload.driver = { id: Number(driverId) };
  }

  try {
    const res = await fetch(`${API_BASE}/rides/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });

    if (!res.ok) {
      const err = await res.text();
      throw new Error(err || "Failed to update ride");
    }

    const updated = await res.json();
    showToast(`Ride #${updated.id} (${updated.origin} ➔ ${updated.destination}) updated!`, "success");
    closeModal("editRideModal");
    await loadAllRides();

    // Also refresh search results if search is active
    const searchOrigin = document.getElementById("searchOrigin").value.trim();
    const searchDest = document.getElementById("searchDestination").value.trim();
    if (searchOrigin && searchDest) {
      searchRides();
    }
  } catch (error) {
    console.error("Error updating ride:", error);
    showToast(`Update failed: ${error.message}`, "error");
  }
}

// --- DELETE RIDE ---

function confirmDeleteRide(id, origin, destination) {
  state.pendingDeleteAction = async () => {
    try {
      const res = await fetch(`${API_BASE}/rides/${id}`, { method: "DELETE" });
      if (!res.ok) {
        const err = await res.text();
        throw new Error(err || "Failed to delete ride");
      }
      showToast(`Ride #${id} (${origin} ➔ ${destination}) deleted successfully`, "success");
      closeModal("confirmDeleteModal");
      await loadAllRides();

      // Refresh search if active
      const searchOrigin = document.getElementById("searchOrigin").value.trim();
      const searchDest = document.getElementById("searchDestination").value.trim();
      if (searchOrigin && searchDest) {
        searchRides();
      }
    } catch (error) {
      console.error("Error deleting ride:", error);
      showToast(`Delete failed: ${error.message}`, "error");
    }
  };

  document.getElementById("confirmDeleteTitle").textContent = "Delete Ride Offer";
  document.getElementById("confirmDeleteMessage").innerHTML = `
    Are you sure you want to delete ride <strong>#${id} (${escapeHtml(origin)} ➔ ${escapeHtml(destination)})</strong>?<br><br>
    <span style="color: var(--danger); font-size: 13px;">⚠️ This action cannot be undone.</span>
  `;

  openModal("confirmDeleteModal");
}

// --- SEARCH RIDES ---

async function searchRides() {
  const origin = document.getElementById("searchOrigin").value.trim();
  const destination = document.getElementById("searchDestination").value.trim();

  if (!origin || !destination) {
    showToast("Please enter both origin and destination to search.", "error");
    return;
  }

  const resultsHeader = document.getElementById("searchResultsHeader");
  const resultsContainer = document.getElementById("rideResults");

  try {
    const res = await fetch(`${API_BASE}/rides/search?origin=${encodeURIComponent(origin)}&destination=${encodeURIComponent(destination)}`);
    if (!res.ok) throw new Error("Search request failed");

    const matches = await res.json();
    if (resultsHeader) resultsHeader.style.display = "flex";

    renderRides(matches, "rideResults");
    showToast(`Found ${matches.length} matching ride${matches.length === 1 ? '' : 's'}.`, "info");
  } catch (error) {
    console.error("Error searching rides:", error);
    if (resultsContainer) {
      resultsContainer.innerHTML = `
        <div class="empty-state">
          <div class="empty-icon">⚠️</div>
          <p>Search failed: ${escapeHtml(error.message)}</p>
        </div>`;
    }
  }
}

function clearSearch() {
  document.getElementById("searchOrigin").value = "";
  document.getElementById("searchDestination").value = "";
  const resultsContainer = document.getElementById("rideResults");
  const resultsHeader = document.getElementById("searchResultsHeader");
  if (resultsContainer) resultsContainer.innerHTML = "";
  if (resultsHeader) resultsHeader.style.display = "none";
}

// --- MODAL UTILITIES ---

function openModal(modalId) {
  const modal = document.getElementById(modalId);
  if (modal) {
    modal.classList.add("active");
    document.body.style.overflow = "hidden";
  }
}

function closeModal(modalId) {
  const modal = document.getElementById(modalId);
  if (modal) {
    modal.classList.remove("active");
    document.body.style.overflow = "";
  }
}

function executeDeleteConfirmed() {
  if (typeof state.pendingDeleteAction === "function") {
    state.pendingDeleteAction();
  }
}

function setupModalBackdrops() {
  document.querySelectorAll(".modal-overlay").forEach(overlay => {
    overlay.addEventListener("click", e => {
      if (e.target === overlay) {
        closeModal(overlay.id);
      }
    });
  });

  document.addEventListener("keydown", e => {
    if (e.key === "Escape") {
      document.querySelectorAll(".modal-overlay.active").forEach(m => closeModal(m.id));
    }
  });
}